# RUNDEAFIX FIRE CE RUN — Android

Projeto Android pronto para abrir no Android Studio e gerar APK/AAB.

- Aplicativo: RUNDEAFIX FIRE CE RUN
- Criadora: Thayná Barros
- Pacote: ce.rundeafix.firecerun
- Versão: 1.0.0
- Interface visual acessível, vibração, treinos, corrida, respiração e perfil.

## Gerar APK
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar e baixar as dependências.
3. Execute `Build > Build APK(s)`.
4. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Observação: o ambiente desta conversa não possui Android SDK/Gradle nem acesso de rede para instalar esses componentes, portanto o APK binário não pôde ser compilado aqui. O projeto está preparado para compilação em um ambiente Android.
