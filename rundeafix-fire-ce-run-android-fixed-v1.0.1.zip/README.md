# RUNDEAFIX FIRE CE RUN — compilação APK pela nuvem

- Nome: RUNDEAFIX FIRE CE RUN
- Criadora: Thayná Barros
- Pacote Android: `ce.rundeafix.firecerun`
- Versão: `1.0.0`

## Como gerar o APK usando apenas o celular

1. Baixe este ZIP e extraia os arquivos no celular.
2. No navegador, entre em https://github.com e crie uma conta ou faça login.
3. Crie um repositório novo chamado `rundeafix-fire-ce-run`. Para simplificar, deixe-o **público** e não marque para adicionar README, licença ou `.gitignore`.
4. Abra o repositório e use **Add file > Upload files**. Envie todos os arquivos e pastas que estão dentro desta pasta extraída, incluindo a pasta oculta `.github`.
   - Se o celular não mostrar `.github`, ative a opção de mostrar arquivos ocultos no gerenciador de arquivos, ou use a versão desktop do site no Chrome.
5. Toque em **Commit changes**.
6. No repositório, abra a aba **Actions**. Se aparecer um aviso para habilitar workflows, confirme.
7. Abra a execução chamada **Build RUNDEAFIX FIRE CE RUN APK** e aguarde terminar com um visto verde.
8. Dentro dessa execução, desça até **Artifacts** e toque em `RUNDEAFIX-FIRE-CE-RUN-APK` para baixar o APK.
9. Extraia o ZIP do artifact, toque em `app-debug.apk` e siga as instruções do Android para instalar. Talvez seja necessário autorizar o Chrome ou o app Arquivos a instalar apps desconhecidos.

## Observações

- O workflow compila um APK de **debug para teste**, não um APK assinado para distribuição pública nem um pacote AAB da Google Play.
- O APK gerado deve ser testado no aparelho antes de qualquer publicação.
- O projeto usa uma interface local dentro de uma WebView. Recursos como GPS real, rastreamento em segundo plano e publicação na Play Store não estão garantidos nesta versão inicial.
- O GitHub Actions salva o APK como artifact por 14 dias; baixe-o antes de expirar.


## Correção v1.0.1
Corrigido erro de JavaScript que deixava a tela principal vazia no WebView Android.
